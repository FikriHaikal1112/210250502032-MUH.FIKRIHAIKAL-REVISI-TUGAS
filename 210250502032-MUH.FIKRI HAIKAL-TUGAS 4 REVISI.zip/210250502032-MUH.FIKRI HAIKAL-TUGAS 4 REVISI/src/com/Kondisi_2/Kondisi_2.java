
package com.Kondisi_2;
import java.util.Scanner;

public class Kondisi_2 {
    public static void main(String[] args) {
       int biaya , jam ;
       
       biaya = 0;
       Scanner in=new Scanner(System.in);
       
       System.out.println("Kondisi 2");
       System.out.println("masukkan berapa lama waktu parkir :");
       
       /* waktu parkir di input dalam satuan jam . jika kurang dari jam yang ditetapkan  
       maka akan dibulatkan */
       jam =in.nextInt();
       
       if(jam == 1){
       
       biaya += 3000;
       
       {System.out.println("biaya pembayaran = Rp."+ biaya);}}
    
       else if (jam >1 && jam<=3){
           biaya +=3000;
           jam-=1;
           biaya += jam * biaya ;
       {System.out.println("biaya pembayaran = Rp."+ biaya);}}
       
       else { 
           {System.out.println("biaya pembayaran = Rp.10000");}} 
 
    }
}
