
package com.Kondisi_3;

import java.util.Scanner;


public class Kondisi_3 {
    public static void main(String[] args) {
       int  biaya , jam;
       
       biaya = 0;
       Scanner in=new Scanner(System.in);
       
       System.out.println("Kondisi 3");
       System.out.println("masukkan berapa lama waktu parkir :");
       
    /* waktu parkir di input dalam satuan jam . jika kurang dari jam yang ditetapkan  
       maka akan dibulatkan */
       
       jam =in.nextInt();
        
       if ( jam == 1 ){
           biaya += 3000;            
       } else {
           if ( jam >1){
            biaya += 3000;
            jam-= 1;
            biaya += jam*biaya ;
           if (biaya >=10000) {
            biaya = 10000;  
       }
       }
        else { 
            System.out.println("input error ");
       }
       }
        System.out.println("Biaya Pembayaran = Rp." +biaya );
}
}