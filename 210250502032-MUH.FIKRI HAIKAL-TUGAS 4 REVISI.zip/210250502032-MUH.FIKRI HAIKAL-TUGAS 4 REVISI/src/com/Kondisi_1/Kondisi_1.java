
package com.Kondisi_1;

import java.util.Scanner;

public class Kondisi_1 {
    public static void main(String[] args) {
       int biaya, jam;
       
       biaya = 3000;
       
       Scanner in=new Scanner(System.in);
       
       System.out.println("Kondisi 1 ");
       System.out.println("masukkan berapa lama waktu parkir :");
       
    /* waktu parkir di input dalam satuan jam . jika kurang dari jam yang ditetapkan  
       maka akan dibulatkan */
       
       jam =in.nextInt();
        
       if(jam>=1&&jam<=3){
              
       biaya = ( biaya * jam) ;
       
       {System.out.println("biaya pembayaran = "+ biaya);}}
          
       else{System.out.println("biaya pembayaran = 10000");} 
    }
}
